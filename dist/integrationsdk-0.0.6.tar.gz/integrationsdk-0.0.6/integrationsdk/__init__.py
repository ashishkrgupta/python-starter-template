
"""
pyexample.

An example python library.
"""

__version__ = "0.1.0"
__author__ = 'Ashish Kumar Gupta'
__credits__ = 'Securonix'
