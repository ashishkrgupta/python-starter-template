#!/usr/bin/env python
import sys

for arg in sys.argv:
    print(arg)