
=======
Credits
=======

Development Lead
----------------

* {{ cookiecutter.author }} <{{ cookiecutter.email }}>

Contributors
------------

None yet. Why not be the first?
